const express = require("express");
const router = express.Router();
const verifyToken = require("../middlewares/auth");
const taskController = require("../controllers/task.controller");
router.route("/api/v1/tasks").post(verifyToken,taskController.createTask)
module.exports = router;
