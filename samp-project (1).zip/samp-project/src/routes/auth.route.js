const express = require("express");
const router = express.Router();

const authController = require("../controllers/auth.controller");
router.route("/api/v1/login").post(authController.login);
module.exports = router;
