const User = require("../models/user.model");
module.exports.getUSerByEmail = async (email) => {
  return await User.findOne({ email: email });
};
module.exports.createUSer = async(userData)=>{
    return await User.create(userData)
}