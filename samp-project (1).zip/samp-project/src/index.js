const app = require("./app");
require("dotenv").config();
const PORT = 3000;
const connectDB = require("./db/connectDB");
connectDB();

const server = app.listen(PORT, () => {
  console.log(`App Listening on ${PORT}`);
});