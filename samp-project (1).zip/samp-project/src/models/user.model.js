const mongoose = require("mongoose");
const userSchema = mongoose.Schema({
  name: {
    type: String,
  },
  email: {
    type: String,
  },
  profilePic: {
    type: String,
  },
  role: {
    type: String,
    enum: ["admin", "team_lead", "developer"],
    default: "user",
  },
});
const user = mongoose.model("users", userSchema);
module.exports = user;
