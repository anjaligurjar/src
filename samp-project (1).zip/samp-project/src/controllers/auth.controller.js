const status = require("http-status");
const jwt = require("jsonwebtoken");
const userServices = require("../services/user.services");
module.exports.login = async (req, res, next) => {
  try {
    const { email, role } = req.body;
    const user = await userServices.getUSerByEmail(email);
    console.log(user);
    if (user) {
      return res.status(status.BAD_REQUEST).json({
        message: `USer Alrady Exists With Email ${email}`,
        statusCode: status.BAD_REQUEST,
      });
    }
    const createdUser = await userServices.createUSer({
      email: email,
      role: role,
    });
    if (createdUser) {
      const token = jwt.sign(
        {
          _id: createdUser._id,
          email: createdUser.email,
          role: createdUser.role,
        },
        "Kamlesh@123",
        {
          expiresIn: "2h",
        }
      );
      return res.status(status.OK).json({
        message: `success`,
        statusCode: status.OK,
        Token: token,
      });
    }
  } catch (error) {
    return res.status(status.INTERNAL_SERVER_ERROR).json({
      message: error.message,
      statusCode: status.INTERNAL_SERVER_ERROR,
    });
  }
};
