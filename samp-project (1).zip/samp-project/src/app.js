const express = require("express");
require("dotenv").config();
var bodyParser = require("body-parser");
const authRouter = require("./routes/auth.route");
const taskRouter = require('./routes/task.route')
const app = express();

// middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use(authRouter);
app.use(taskRouter)

module.exports = app;
