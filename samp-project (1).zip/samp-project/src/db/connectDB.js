const mongoose = require("mongoose");
const db = 'mongodb+srv://Kamal9462:Kamal9462@cluster0.llk00.mongodb.net/?retryWrites=true&w=majority';
console.log(db);
const connectDB = async () => {
  mongoose.set("strictQuery", true);
  await mongoose
    .connect(db, {
      keepAlive: true,
      useNewUrlParser: true,
      useUnifiedTopology: true,
    })
    .then((x) => {
      console.log(
        `Connected to Mongo! Database name: "${x.connections[0].name}"`
      );
    })
    .catch((err) => {
      console.error("Error connecting to mongo", err);
    });
  return mongoose;
};

module.exports = connectDB;
